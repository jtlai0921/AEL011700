﻿Module Module1

    Sub Main()
        Dim name As String
        Console.Write("請輸入姓名 ==> ")
        name = Console.ReadLine()
        Console.WriteLine("輸入的姓名: " & name)
        Console.Read()
    End Sub

End Module

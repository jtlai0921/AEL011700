﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Label1.ForeColor = Color.Blue
        TextBox1.Text = Label1.Text
        Label1.Text = "Visual Basic程式設計"
        Do

        Loop While True

    End Sub
End Class
